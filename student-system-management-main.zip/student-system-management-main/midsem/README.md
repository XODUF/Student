# Student Management System Plus (JavaFX)

This is a professional desktop application built with JavaFX and SQLite for managing student records.

## Project Structure
- `src/main/java`: Java source code (Domain, Service, Repository, Controller)
- `src/main/resources`: FXML views and assets
- `data/`: SQLite database and logs (generated at runtime)
- `pom.xml`: Maven configuration

## How to Run (Windows)
1. Ensure you have **JDK 21** installed.
2. Download **JavaFX SDK 21.0.10**.
3. Use the VM options provided in `RUN_VM_OPTIONS.txt`.
4. Run via IDE (VS Code/IntelliJ) or Maven:
   ```bash
   mvn javafx:run
   ```

## Troubleshooting: "JavaFX runtime components are missing"
If you see this error in VS Code:
1. **Use the Launcher**: Right-click `src/main/java/com/smsplus/Launcher.java` and select **Run**.
2. **Check SDK Path**: Ensure your JavaFX SDK is at `C:\javafx\javafx-sdk-21.0.10`. If it is in a different folder, update the path in `.vscode/launch.json` and `RUN_VM_OPTIONS.txt`.
3. **VM Options**: If running from terminal, use:
   ```bash
   java --module-path "path/to/javafx/lib" --add-modules javafx.controls,javafx.fxml -cp bin com.smsplus.Launcher
   ```
