import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const app = express();
const PORT = 3000;
const DATA_DIR = path.join(process.cwd(), "data");
const DB_PATH = path.join(DATA_DIR, "students.db");
const LOG_FILE = path.join(DATA_DIR, "app.log");

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR);
}

// Initialize Database
const db = new Database(DB_PATH);

// Create Tables
db.exec(`
  CREATE TABLE IF NOT EXISTS students (
    student_id TEXT PRIMARY KEY,
    full_name TEXT NOT NULL,
    programme TEXT NOT NULL,
    level INTEGER NOT NULL,
    gpa REAL NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL,
    date_added TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('Active', 'Inactive')),
    CHECK (level IN (100, 200, 300, 400, 500, 600, 700)),
    CHECK (gpa >= 0.0 AND gpa <= 4.0)
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  INSERT OR IGNORE INTO settings (key, value) VALUES ('at_risk_threshold', '2.0');
`);

app.use(express.json({ limit: '50mb' }));

// Logging Helper
function log(message: string) {
  const timestamp = new Date().toISOString();
  const logEntry = `[${timestamp}] ${message}\n`;
  fs.appendFileSync(LOG_FILE, logEntry);
  console.log(logEntry.trim());
}

// --- API Routes ---

// Stats
app.get("/api/stats", (req, res) => {
  try {
    const total = db.prepare("SELECT COUNT(*) as count FROM students").get() as any;
    const active = db.prepare("SELECT COUNT(*) as count FROM students WHERE status = 'Active'").get() as any;
    const inactive = db.prepare("SELECT COUNT(*) as count FROM students WHERE status = 'Inactive'").get() as any;
    const avgGpa = db.prepare("SELECT AVG(gpa) as avg FROM students").get() as any;

    res.json({
      total: total.count,
      active: active.count,
      inactive: inactive.count,
      avgGpa: avgGpa.avg || 0
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Students CRUD
app.get("/api/students", (req, res) => {
  try {
    const students = db.prepare("SELECT * FROM students ORDER BY date_added DESC").all();
    res.json(students);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/students", (req, res) => {
  const { student_id, full_name, programme, level, gpa, email, phone, status } = req.body;
  try {
    const date_added = new Date().toISOString();
    const stmt = db.prepare(`
      INSERT INTO students (student_id, full_name, programme, level, gpa, email, phone, date_added, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(student_id, full_name, programme, level, gpa, email, phone, date_added, status);
    log(`Added student: ${student_id}`);
    res.status(201).json({ success: true });
  } catch (err: any) {
    log(`Failed to add student ${student_id}: ${err.message}`);
    res.status(400).json({ error: err.message });
  }
});

app.put("/api/students/:id", (req, res) => {
  const { id } = req.params;
  const { full_name, programme, level, gpa, email, phone, status } = req.body;
  try {
    const stmt = db.prepare(`
      UPDATE students 
      SET full_name = ?, programme = ?, level = ?, gpa = ?, email = ?, phone = ?, status = ?
      WHERE student_id = ?
    `);
    const result = stmt.run(full_name, programme, level, gpa, email, phone, status, id);
    if (result.changes === 0) return res.status(404).json({ error: "Student not found" });
    log(`Updated student: ${id}`);
    res.json({ success: true });
  } catch (err: any) {
    log(`Failed to update student ${id}: ${err.message}`);
    res.status(400).json({ error: err.message });
  }
});

app.delete("/api/students/:id", (req, res) => {
  const { id } = req.params;
  try {
    const stmt = db.prepare("DELETE FROM students WHERE student_id = ?");
    stmt.run(id);
    log(`Deleted student: ${id}`);
    res.json({ success: true });
  } catch (err: any) {
    log(`Failed to delete student ${id}: ${err.message}`);
    res.status(500).json({ error: err.message });
  }
});

// Reports
app.get("/api/reports/top-performers", (req, res) => {
  const { programme, level } = req.query;
  try {
    let query = "SELECT * FROM students WHERE 1=1";
    const params: any[] = [];
    if (programme) { query += " AND programme = ?"; params.push(programme); }
    if (level) { query += " AND level = ?"; params.push(level); }
    query += " ORDER BY gpa DESC LIMIT 10";
    const results = db.prepare(query).all(...params);
    res.json(results);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/reports/at-risk", (req, res) => {
  try {
    const thresholdSetting = db.prepare("SELECT value FROM settings WHERE key = 'at_risk_threshold'").get() as any;
    const threshold = parseFloat(thresholdSetting?.value || "2.0");
    const results = db.prepare("SELECT * FROM students WHERE gpa < ? ORDER BY gpa ASC").all(threshold);
    res.json(results);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/reports/distribution", (req, res) => {
  try {
    const bands = [
      { name: "0.0 - 1.0", min: 0, max: 1 },
      { name: "1.0 - 2.0", min: 1, max: 2 },
      { name: "2.0 - 3.0", min: 2, max: 3 },
      { name: "3.0 - 4.0", min: 3, max: 4.1 },
    ];
    const data = bands.map(band => {
      const count = db.prepare("SELECT COUNT(*) as count FROM students WHERE gpa >= ? AND gpa < ?").get(band.min, band.max) as any;
      return { name: band.name, count: count.count };
    });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/reports/programme-summary", (req, res) => {
  try {
    const results = db.prepare(`
      SELECT programme as name, COUNT(*) as count, AVG(gpa) as avgGpa 
      FROM students 
      GROUP BY programme
    `).all();
    res.json(results);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Settings
app.get("/api/settings", (req, res) => {
  try {
    const settings = db.prepare("SELECT * FROM settings").all();
    const config: any = {};
    settings.forEach((s: any) => config[s.key] = s.value);
    res.json(config);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/settings", (req, res) => {
  const { at_risk_threshold } = req.body;
  try {
    db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)").run('at_risk_threshold', at_risk_threshold.toString());
    log(`Updated settings: at_risk_threshold = ${at_risk_threshold}`);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Import/Export (Simplified for Web)
app.post("/api/import", (req, res) => {
  const { students } = req.body; // Array of student objects
  let successCount = 0;
  let errorCount = 0;
  const errors: any[] = [];

  const insertStmt = db.prepare(`
    INSERT INTO students (student_id, full_name, programme, level, gpa, email, phone, date_added, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const date_added = new Date().toISOString();

  db.transaction(() => {
    for (const s of students) {
      try {
        // Basic Validation
        if (!s.student_id || s.student_id.length < 4 || s.student_id.length > 20) throw new Error("Invalid ID length");
        if (!/^[a-zA-Z0-9]+$/.test(s.student_id)) throw new Error("ID must be alphanumeric");
        if (!s.full_name || s.full_name.length < 2 || s.full_name.length > 60) throw new Error("Invalid name length");
        if (/\d/.test(s.full_name)) throw new Error("Name cannot contain digits");
        if (![100, 200, 300, 400, 500, 600, 700].includes(Number(s.level))) throw new Error("Invalid level");
        if (s.gpa < 0 || s.gpa > 4) throw new Error("GPA must be 0-4");
        if (!s.email.includes("@") || !s.email.includes(".")) throw new Error("Invalid email");
        if (!/^\d{10,15}$/.test(s.phone)) throw new Error("Phone must be 10-15 digits");

        insertStmt.run(s.student_id, s.full_name, s.programme, s.level, s.gpa, s.email, s.phone, date_added, s.status || 'Active');
        successCount++;
      } catch (err: any) {
        errorCount++;
        errors.push({ id: s.student_id, error: err.message });
      }
    }
  })();

  log(`Import completed: ${successCount} success, ${errorCount} errors`);
  res.json({ successCount, errorCount, errors });
});

// --- Vite Middleware ---
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(process.cwd(), "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(process.cwd(), "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
