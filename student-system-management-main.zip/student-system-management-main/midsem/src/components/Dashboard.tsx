import React, { useEffect, useState } from 'react';
import { Users, UserCheck, UserX, GraduationCap, TrendingUp, AlertCircle } from 'lucide-react';
import { DashboardStats } from '../types';
import { motion } from 'motion/react';

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);

  useEffect(() => {
    fetch('/api/stats')
      .then(res => res.json())
      .then(data => setStats(data));
  }, []);

  if (!stats) return <div className="animate-pulse">Loading stats...</div>;

  const cards = [
    { label: 'Total Students', value: stats.total, icon: Users, color: 'bg-blue-500' },
    { label: 'Active Students', value: stats.active, icon: UserCheck, color: 'bg-emerald-500' },
    { label: 'Inactive Students', value: stats.inactive, icon: UserX, color: 'bg-amber-500' },
    { label: 'Average GPA', value: stats.avgGpa.toFixed(2), icon: GraduationCap, color: 'bg-violet-500' },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4"
          >
            <div className={`${card.color} p-3 rounded-xl text-white`}>
              <card.icon size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">{card.label}</p>
              <p className="text-2xl font-bold text-gray-900">{card.value}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold flex items-center gap-2">
              <TrendingUp size={20} className="text-emerald-500" />
              System Overview
            </h3>
          </div>
          <div className="space-y-6">
            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100">
              <p className="text-emerald-800 font-medium">Department Performance</p>
              <p className="text-sm text-emerald-600 mt-1">
                The current average GPA is {stats.avgGpa.toFixed(2)}. This is within the target range for this semester.
              </p>
            </div>
            <div className="p-4 bg-amber-50 rounded-xl border border-amber-100">
              <p className="text-amber-800 font-medium">Data Integrity</p>
              <p className="text-sm text-amber-600 mt-1">
                {stats.inactive} student records are currently marked as inactive. Consider archiving old records.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-[#151619] text-white p-8 rounded-2xl shadow-xl">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <AlertCircle size={20} className="text-amber-400" />
            Quick Actions
          </h3>
          <div className="space-y-3">
            <button className="w-full text-left p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/5">
              <p className="font-medium">Generate Semester Report</p>
              <p className="text-xs text-gray-400">Export all current performance data</p>
            </button>
            <button className="w-full text-left p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/5">
              <p className="font-medium">Review At-Risk Students</p>
              <p className="text-xs text-gray-400">View students below GPA threshold</p>
            </button>
            <button className="w-full text-left p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/5">
              <p className="font-medium">Database Backup</p>
              <p className="text-xs text-gray-400">Last backup: 2 hours ago</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
